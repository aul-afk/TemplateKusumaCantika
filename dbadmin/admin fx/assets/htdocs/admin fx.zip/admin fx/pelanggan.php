<?php
include 'config.php';

if (isset($_POST['add_customer'])) {

    $name = $_POST['customer_name'];
    $gender = $_POST['gender'];
    $phone = $_POST['phone_number'];
    $address = $_POST['address'];

    mysqli_query($conn, "INSERT INTO customer (customer_name, gender, phone_number, address)
                         VALUES ('$name', '$gender', '$phone', '$address')");

    echo "<script>alert('Customer berhasil ditambahkan!'); window.location='pelanggan.php';</script>";
}
if (isset($_POST['update_customer'])) {
    $id     = $_POST['customer_id'];
    $name   = $_POST['customer_name'];
    $gender = $_POST['gender'];
    $phone  = $_POST['phone_number'];
    $addr   = $_POST['address'];

    $update = mysqli_query($conn, "
        UPDATE customer SET
            customer_name='$name',
            gender='$gender',
            phone_number='$phone',
            address='$addr'
        WHERE customer_id='$id'
    ");

    if ($update) {
        echo "<script>alert('Customer updated'); window.location='pelanggan.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>


<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Paper Dashboard by Creative Tim</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />

    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

</head>
<body>

<div class="wrapper">
	<div class="sidebar" data-background-color="white" data-active-color="danger">

    <!--
		Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
		Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
	-->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <img src="kusuma.jpg" alt="" width="80" />
            </div>

            <ul class="nav">
                <li>
                    <a href="dashboard.php">
                        <i class="ti-panel"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li>
                    <a href="rental.php">
                        <i class="ti-tag"></i>
                        <p>Rental</p>
                    </a>
                </li>
                <li>
                    <a href="check.php">
                        <i class="ti-check"></i>
                        <p>Check</p>
                    </a>
                </li>
                <li>
                    <a href="kostum.php">
                       <i class="fa-solid fa-shirt"></i>
                        <p>Kostum</p>
                    </a>
                </li>
                <li class="active">
                    <a href="pelanggan.php">
                        <i class="fa-solid fa-users"></i>
                        <p>Pelanggan</p>
                    </a>
                </li>
                <li>
                    <a href="owner.php">
                        <i class="ti-user"></i>
                        <p>Admin</p>
                    </a>
                </li>
            </ul>
    	</div>
    </div>

    <div class="main-panel">
		<nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#">Data Pelanggan</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="ti-panel"></i>
								<p>Stats</p>
                            </a>
                        </li>
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="ti-bell"></i>
                                    <p class="notification">5</p>
									<p>Notifications</p>
									<b class="caret"></b>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Notification 1</a></li>
                                <li><a href="#">Notification 2</a></li>
                                <li><a href="#">Notification 3</a></li>
                                <li><a href="#">Notification 4</a></li>
                                <li><a href="#">Another notification</a></li>
                              </ul>
                        </li>
						<li>
                            <a href="#">
								<i class="ti-settings"></i>
								<p>Settings</p>
                            </a>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>
        <link rel="stylesheet" href="../../assets/css/style.css">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <!-- Tailwind CSS (opsional jika AdminMart belum pakai) -->
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<style>
/* ===== STYLE TAMBAHAN UNTUK TABEL AGAR SAMA DENGAN KOSTUM ===== */
.table-container {
  background-color: #ffffff;
  border-radius: 12px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.08);
  margin: 20px auto;
  overflow: hidden;
}

.table-header {
  background-color: #f79c7bff; /* Tailwind: bg-blue-600 */
  color: #fff;
  padding: 12px 20px;
  font-size: 1.25rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 10px;
}

.table-content {
  width: 100%;
  border-collapse: collapse;
}

.table-content th {
  background-color: #fbb097ff; /* Tailwind: bg-blue-500 */
  color: #fff;
  text-align: left;
  padding: 10px 14px;
  font-weight: 600;
  font-size: 0.95rem;
}

.table-content td {
  padding: 10px 14px;
  border-bottom: 1px solid #ffcbbdff; /* Tailwind: border-gray-200 */
  font-size: 0.9rem;
}

.table-content tr:hover {
  background-color: #f1f5f9; /* Tailwind: bg-gray-100 */
}


.gender-male {
  color: #2563eb;
  font-weight: 500;
}
.gender-female {
  color: #db2777;
  font-weight: 500;
}
table {
        width: 100%;
        border-collapse: collapse;
        font-size: 22px; /* ukuran tulisan isi tabel diperbesar */
    }
th, td {
        padding: 16px;
        text-align: center;
        border-bottom: 1px solid #ddd;
    }
.card-body {
        padding: 0 20px 20px 20px;
    }
.action-btns a {
      padding: 5px 8px;
      margin: 0 3px;
      border-radius: 4px;
      font-size: 12px;
      color: white;
      text-decoration: none;
    }

.btn-add {
    display: inline-block;
    position: relative;
    margin: 35px auto; /* Biar posisinya di tengah */
    padding: 12px 25px;
    background-color: #F39C75; /* Sesuaikan warna */
    color: white;
    font-weight: bold;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    box-shadow: 0 4px 10px rgba(0,0,0,0.15); /* efek melayang */
    transition: 0.3s ease;
}

/* Efek hover */
.btn-add:hover {
    background-color: #e68b63;
    transform: translateY(-3px); /* supay melayang naik sedikit */
}

/* Efek klik */
.btn-add:active {
    transform: translateY(0px);
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}
.box-add {
    background-color: #F39C75;
    display: inline-block;
    padding: 15px 25px;
    border-radius: 10px;
    margin: 20px auto;
}


.btn-action {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 6px 10px;
  font-size: 13px;
  border-radius: 6px;
  margin-right: 5px;
  text-decoration: none;
  color: white;
  transition: 0.2s ease;
}

.btn-view {
  background-color: #5bc0de;
}
.btn-view:hover {
  background-color: #31b0d5;
}

.btn-edit {
  background-color: #f79c7b;
}
.btn-edit:hover {
  background-color: #f57c52;
}

.btn-delete {
  background-color: #dc3545;
}
.btn-delete:hover {
  background-color: #b02a37;
}

.table-actions {
  text-align: center;
  white-space: nowrap;
}
/* === FORM ADD & EDIT STYLING === */
.edit-card {
  background: #ffffff;
  border-radius: 12px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.08);
  padding: 20px 25px;
  margin: 25px;
  border-left: 6px solid #f79c7bff;
}

.edit-title {
  font-size: 22px;
  font-weight: 600;
  margin-bottom: 15px;
  color: #f07954;
}

.edit-form label {
  font-weight: 600;
  color: #444;
}

.edit-form input {
  width: 100%;
  padding: 10px 12px;
  margin-bottom: 15px;
  font-size: 15px;
  border: 1px solid #ffcbbdff;
  border-radius: 8px;
  background: #fff8f6;
  transition: 0.2s;
}

.edit-form input:focus {
  border-color: #f79c7bff;
  background: #fff;
  outline: none;
  box-shadow: 0 0 4px rgba(247, 156, 123, 0.5);
}

.btn-save {
  background: #f79c7bff;
  color: white;
  padding: 10px 14px;
  font-size: 14px;
  border-radius: 8px;
  border: none;
  cursor: pointer;
  transition: 0.2s;
}

.btn-save:hover {
  background: #f06f3fff;
  transform: translateY(-2px);
}

.btn-cancel {
  padding: 10px 14px;
  background: #ef4444;
  color: white;
  text-decoration: none;
  border-radius: 8px;
  margin-left: 10px;
}

</style>
<?php if (isset($_POST['show_add_form'])) { ?>
<div class="edit-card">
    <h3 class="edit-title">Tambah Customer</h3>

    <form method="POST" class="edit-form">

        <label>Nama Customer</label>
        <input type="text" name="customer_name" required>

        <label>Jenis Kelamin</label>
        <select name="gender" required style="margin-bottom:15px; padding:10px; border:1px solid #ffcbbdff; border-radius:8px; background:#fff8f6;">
            <option value="">Pilih...</option>
            <option value="male">Laki-laki</option>
            <option value="female">Perempuan</option>
        </select>

        <label>No. Telepon</label>
        <input type="text" name="phone_number" required>

        <label>Alamat</label>
        <input type="text" name="address" required>

        <button type="submit" name="add_customer" class="btn-save">Simpan</button>

        <a href="pelanggan.php" class="btn-cancel">Batal</a>
    </form>
</div>
<?php } ?>


<!-- ===================== -->
<!-- 💠 DATA PELANGGAN -->
<!-- ===================== -->
 <div style="margin: 10px 0;">
    <form method="POST">
        <button type="submit" name="show_add_form" 
            class="btn-add"
   style="margin-top: 10px; margin-bottom: -10px;">
            + Tambah Customer
        </button>
    </form>
</div>
<div class="table-container">
  <div class="table-header">
  </div>
  <div class="card overflow-hidden">
      <div class="overflow-x-auto">
        <table class="min-w-full text-sm text-gray-800">
          <thead>
            <tr class="bg-pink-100 text-left">
              <th>no</th>
              <th>ID Pelanggan</th>
              <th>Nama</th>
              <th>Gender</th>
              <th>No. HP</th>
              <th>Alamat</th>
              <th class="py-3 px-4 border-b text-center" style="width:150px;">Aksi</th>
            </tr>
      </thead>
      <tbody>
       <?php
$query = mysqli_query($conn, "SELECT * FROM customer");
$no = 1;

if (mysqli_num_rows($query) > 0) {
  while ($row = mysqli_fetch_assoc($query)) {
    $genderClass = $row['gender'] === 'male' ? 'gender-male' : 'gender-female';

    echo "
<tr>
  <td>{$no}</td>
  <td>{$row['customer_id']}</td>
  <td>{$row['customer_name']}</td>
  <td class='{$genderClass}'>{$row['gender']}</td>
  <td>{$row['phone_number']}</td>
  <td>{$row['address']}</td>

  <td class='action-btn'>

    <form method='POST' style='display:inline-block;'>
        <input type='hidden' name='edit_customer_id' value='{$row['customer_id']}'>
        <input type='hidden' name='customer_name' value='{$row['customer_name']}'>
        <input type='hidden' name='gender' value='{$row['gender']}'>
        <input type='hidden' name='phone_number' value='{$row['phone_number']}'>
        <input type='hidden' name='address' value='{$row['address']}'>
        
        <button type='submit' name='edit_customer_btn' class='btn-edit'>
            <i class='fa-solid fa-pen-to-square'></i>
        </button>
    </form>

    <a href='delete_pelanggan.php?id={$row['customer_id']}' 
       class='btn-delete' onclick='return confirm(\"Hapus?\")'>
        <i class='fa-solid fa-trash'></i>
    </a>

  </td>

</tr>";

    $no++;
  }
} else {
  echo "<tr><td colspan='8' style='text-align:center; padding:12px;'>Tidak ada data pelanggan</td></tr>";
}
?>


      </tbody>
    </table>
  </div>
</div>