<?php
include 'config.php';
// Total semua kostum
$total_costume = mysqli_fetch_assoc(mysqli_query(
    $conn, "SELECT COUNT(*) AS total FROM costume"
))['total'];

// Kostum tersedia
$available_costume = mysqli_fetch_assoc(mysqli_query(
    $conn, "SELECT COUNT(*) AS total FROM costume WHERE availability = 'yes'"
))['total'];

// Kostum perawatan
$maintenance_costume = mysqli_fetch_assoc(mysqli_query(
    $conn, "SELECT COUNT(*) AS total FROM costume WHERE availability = 'maintenance'"
))['total'];

// Pendapatan bulan ini
$income_month = mysqli_fetch_assoc(mysqli_query(
    $conn, "SELECT SUM(total_amount) AS total FROM rental 
            WHERE MONTH(start_date) = MONTH(CURRENT_DATE())
            AND YEAR(start_date) = YEAR(CURRENT_DATE())"
))['total'];
if ($income_month == null) $income_month = 0;

// Grafik (jumlah disewa per bulan)
$chart_query = mysqli_query(
    $conn, "SELECT MONTH(start_date) AS bulan, COUNT(*) AS total
            FROM rental 
            GROUP BY MONTH(start_date)"
);

// Simpan ke array JS
$months = [];
$values = [];
while ($row = mysqli_fetch_assoc($chart_query)) {
    $months[] = $row['bulan'];
    $values[] = $row['total'];
}
?>
<style>
        body {
            font-family: Arial, sans-serif;
        }

        /* KOTAK INFORMASI */
        .stats-container {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            margin-top: 20px;
        }

        .stat-card {
            width: 23%;
            padding: 20px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            text-align: center;
        }

        .stat-title {
            font-size: 18px;
            color: #444;
        }

        .stat-value {
            font-size: 32px;
            font-weight: bold;
            margin-top: 10px;
            color: #222;
        }

        /* GRAFIK */
        .chart-box {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        #rentalChart {
    width: 100% !important;
    height: 320px !important; 
}

    </style>

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Paper Dashboard by Creative Tim</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="../../assets/css/style.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <!-- Tailwind CSS (opsional jika AdminMart belum pakai) -->
    <script src="https://cdn.tailwindcss.com"></script>

</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-background-color="white" data-active-color="danger">

    <!--
		Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
		Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
	-->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <img src="kusuma.jpg" alt="" width="80" />
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="dashboard.php">
                        <i class="ti-panel"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li>
                    <a href="rental.php">
                        <i class="ti-tag"></i>
                        <p>Rental</p>
                    </a>
                </li>
                <li>
                    <a href="check.php">
                        <i class="ti-check"></i>
                        <p>Check</p>
                    </a>
                </li>
                  <li>
                    <a href="kostum.php">
                       <i class="fa-solid fa-shirt"></i>
                        <p>Kostum</p>
                    </a>
                </li>
                <li>
                    <a href="pelanggan.php">
                        <i class="fa-solid fa-users"></i>
                        <p>Pelanggan</p>
                    </a>
                </li>
                <li>
                    <a href="owner.php">
                        <i class="ti-user"></i>
                        <p>Admin</p>
                    </a>
                </li>
            </ul>
    	</div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="ti-panel"></i>
								<p>Stats</p>
                            </a>
                        </li>
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="ti-bell"></i>
                                    <p class="notification">5</p>
									<p>Notifications</p>
									<b class="caret"></b>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Notification 1</a></li>
                                <li><a href="#">Notification 2</a></li>
                                <li><a href="#">Notification 3</a></li>
                                <li><a href="#">Notification 4</a></li>
                                <li><a href="#">Another notification</a></li>
                              </ul>
                        </li>
						<li>
                            <a href="#">
								<i class="ti-settings"></i>
								<p>Settings</p>
                            </a>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>


        <body>

<!-- 4 KOTAK INFO -->
<div class="stats-container">

    <div class="stat-card">
        <div class="stat-title">Total Costume</div>
        <div class="stat-value"><?= $total_costume ?></div>
    </div>

    <div class="stat-card">
        <div class="stat-title">Costume Tersedia</div>
        <div class="stat-value"><?= $available_costume ?></div>
    </div>

    <div class="stat-card">
        <div class="stat-title">Costume Perawatan</div>
        <div class="stat-value"><?= $maintenance_costume ?></div>
    </div>

    <div class="stat-card">
        <div class="stat-title">Pendapatan Bulan Ini</div>
        <div class="stat-value">Rp <?= number_format($income_month, 0, ',', '.') ?></div>
    </div>

</div>

<!-- GRAFIK -->
<div class="chart-box">
    <h3 style="text-align:center;">Grafik Penyewaan Costume per Bulan</h3>
    <canvas id="rentalChart" height="100"></canvas>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
// Data dari PHP
var months = <?= json_encode($months) ?>;
var values = <?= json_encode($values) ?>;

var ctx = document.getElementById('rentalChart').getContext('2d');
var rentalChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: months,
        datasets: [{
            label: 'Jumlah Penyewaan',
            data: values,
            borderWidth: 3,
            borderColor: 'rgba(54, 162, 235, 1)',
            tension: 0.3
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});
</script>


</body>
</html>
