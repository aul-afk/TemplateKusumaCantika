<?php
include 'config.php';
?>
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Paper Dashboard by Creative Tim</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />

    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

</head>
<body>

<div class="wrapper">
	<div class="sidebar" data-background-color="white" data-active-color="danger">

    <!--
		Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
		Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
	-->

    	   	<div class="sidebar-wrapper">
            <div class="logo">
                <img src="kusuma.jpg" alt="" width="80" />
            </div>

            <ul class="nav">
                <li>
                    <a href="dashboard.php">
                        <i class="ti-panel"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="active">
                    <a href="rental.php">
                        <i class="ti-tag"></i>
                        <p>Rental</p>
                    </a>
                </li>
                <li>
                    <a href="check.php">
                        <i class="ti-check"></i>
                        <p>Check</p>
                    </a>
                </li>
                <li>
                    <a href="kostum.php">
                       <i class="fa-solid fa-shirt"></i>
                        <p>Kostum</p>
                    </a>
                </li>
                <li>
                    <a href="pelanggan.php">
                        <i class="fa-solid fa-users"></i>
                        <p>Pelanggan</p>
                    </a>
                </li>
                <li>
                    <a href="owner.php">
                        <i class="ti-user"></i>
                        <p>Admin</p>
                    </a>
                </li>
            </ul>
    	</div>
    </div>

    <div class="main-panel">
		<nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#">DATA RENTAL</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="ti-panel"></i>
								<p>Stats</p>
                            </a>
                        </li>
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="ti-bell"></i>
                                    <p class="notification">5</p>
									<p>Notifications</p>
									<b class="caret"></b>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Notification 1</a></li>
                                <li><a href="#">Notification 2</a></li>
                                <li><a href="#">Notification 3</a></li>
                                <li><a href="#">Notification 4</a></li>
                                <li><a href="#">Another notification</a></li>
                              </ul>
                        </li>
						<li>
                            <a href="#">
								<i class="ti-settings"></i>
								<p>Settings</p>
                            </a>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>
        <link rel="stylesheet" href="../../assets/css/style.css">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <!-- Tailwind CSS (opsional jika AdminMart belum pakai) -->
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<style>
/* ===== STYLE TAMBAHAN UNTUK TABEL AGAR SAMA DENGAN KOSTUM ===== */

.table-container {
  background-color: #ffffff;
  border-radius: 12px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.08);
  margin: 20px auto;
  overflow: hidden;
}

.table-header {
  background-color: #f79c7bff; /* Tailwind: bg-blue-600 */
  color: #fff;
  padding: 12px 20px;
  font-size: 1.25rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 10px;
}

.table-content {
  width: 100%;
  border-collapse: collapse;
}

.table-content th {
  background-color: #fbb097ff; /* Tailwind: bg-blue-500 */
  color: #fff;
  text-align: left;
  padding: 10px 14px;
  font-weight: 600;
  font-size: 0.95rem;
}

.table-content td {
  padding: 10px 14px;
  border-bottom: 1px solid #ffcbbdff; /* Tailwind: border-gray-200 */
  font-size: 0.9rem;
}

.table-content tr:hover {
  background-color: #f1f5f9; /* Tailwind: bg-gray-100 */
}

 .payment-paid {
        color: #28a745;
        font-weight: bold;
     }
.payment-unpaid {
        color: #dc3545;
        font-weight: bold;
}      
td[class^="status-"] {
    text-align: center;
}

.status-booked,
.status-returned,
.status-borrowed {
    font-weight: bold;
    margin: 0 auto;
    text-align: center;
}

/* Warna sesuai status */
.status-booked {
    color: #ff8c00;
}

.status-returned {
    color: #1b8c3c;
}

.status-borrowed {
    color: #856404;
}
table {
        width: 100%;
        border-collapse: collapse;
        font-size: 22px; /* ukuran tulisan isi tabel diperbesar */
    }
th, td {
        padding: 16px;
        text-align: center;
        border-bottom: 1px solid #ddd;
    }
.card-body {
        padding: 0 20px 20px 20px;
    }
 .action-btns a {
      padding: 5px 8px;
      margin: 0 3px;
      border-radius: 4px;
      font-size: 12px;
      color: white;
      text-decoration: none;
    }
    .btn-space {
    margin-top: 20px;
}

 .btn-tambah-rental {
    display: inline-block;
    position: relative;
    margin: 35px auto; /* Biar posisinya di tengah */
    padding: 12px 25px;
    background-color: #F39C75; /* Sesuaikan warna */
    color: white;
    font-weight: bold;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    box-shadow: 0 4px 10px rgba(0,0,0,0.15); /* efek melayang */
    transition: 0.3s ease;
}

/* Efek hover */
.btn-tambah-rental:hover {
    background-color: #e68b63;
    transform: translateY(-3px); /* supay melayang naik sedikit */
}

/* Efek klik */
.btn-tambah-rental:active {
    transform: translateY(0px);
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}
.box-tambah-rental {
    background-color: #F39C75;
    display: inline-block;
    padding: 15px 25px;
    border-radius: 10px;
    margin: 20px auto;
}


.btn-action {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 6px 10px;
  font-size: 13px;
  border-radius: 6px;
  margin-right: 5px;
  text-decoration: none;
  color: white;
  transition: 0.2s ease;
}

.btn-view {
  background-color: #5bc0de;
}
.btn-view:hover {
  background-color: #31b0d5;
}

.btn-edit {
  background-color: #f79c7b;
}
.btn-edit:hover {
  background-color: #f57c52;
}

.btn-delete {
  background-color: #dc3545;
}
.btn-delete:hover {
  background-color: #b02a37;
}

.table-actions {
  text-align: center;
  white-space: nowrap;
}
</style>

<!-- ===================== -->
<!-- 💠 DATA PELANGGAN -->
<!-- ===================== -->
 <a href="add_rental.php"  class="btn-tambah-rental"
   style="margin-top: 10px; margin-bottom: -10px;">
   <i class="fa fa-plus"></i> Tambah Rental
</a>
<div class="table-container">
  <div class="table-header">
  </div>
  <div class="card overflow-hidden">
      <div class="overflow-x-auto">
        <table class="min-w-full text-sm text-gray-800">
          <thead>
            <tr class="bg-pink-100 text-left">
                <th>Rental ID</th>
                <th>Customer ID</th>
                <th>Costume ID</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Quantity</th>
                <th>Total Amount</th>
                <th>Payment Status</th>
                <th>Status</th>
                <th>Penalty Fee</th>
                 <th class="py-3 px-4 border-b text-center" style="width:150px;">Aksi</th>
            </tr>
            <tbody class="divide-y divide-gray-200">
           <?php
            $query = mysqli_query($conn, "SELECT * FROM rental");
            $no = 1;

            if (mysqli_num_rows($query) > 0) {
              while ($row = mysqli_fetch_assoc($query)) {
                    echo "<tr>";
                    echo "<td>" . $row["rental_id"] . "</td>";
                    echo "<td>" . $row["customer_id"] . "</td>";
                    echo "<td>" . $row["costume_id"] . "</td>";
                    echo "<td>" . $row["start_date"] . "</td>";
                    echo "<td>" . $row["end_date"] . "</td>";
                    echo "<td>" . $row["quantity"] . "</td>";
                    echo "<td>Rp " . number_format($row["total_amount"], 2, ',', '.') . "</td>";

                    // Payment Status
                    $paymentClass = ($row["payment_status"] == 'paid') ? 'payment-paid' : 'payment-unpaid';
                    echo "<td class='$paymentClass'>" . ucfirst($row["payment_status"]) . "</td>";

                    // Status
                    $statusClass = 'status-' . $row["status"];
                    echo "<td class='$statusClass'>" . ucfirst($row["status"]) . "</td>";

                    echo "<td>Rp " . number_format($row["penalty_fee"], 2, ',', '.') . "</td>";
                    echo "<td class='action-btns'>
                        <a href='view_rental.php?id={$row['rental_id']}' class='btn-view'><i class='fa-solid fa-eye'></i></a>
                        <a href='edit_rental.php?id={$row['rental_id']}' class='btn-edit'><i class='fa-solid fa-pen-to-square'></i></a>
                        <a href='delete_rental.php?id={$row['rental_id']}' class='btn-delete' onclick='return confirm(\"Yakin hapus data ini?\")'><i class='fa-solid fa-trash'></i></a>
                        </td>";
                    echo "</tr>";

                    echo "</tr>";
                    
                }
            } else {
                echo "<tr><td colspan='10'>Tidak ada data rental</td></tr>";
            }
            $conn->close();
             ?>
        </tbody>



          </thead>